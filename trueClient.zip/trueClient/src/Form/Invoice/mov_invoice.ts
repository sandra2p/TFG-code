export namespace Invoice {
    export function onLoad(executionContext: Xrm.Events.EventContext) {
        const formContext: Xrm.Mov_invoice = executionContext.getFormContext();
        registerEvents(formContext);
        initForm(formContext);
        console.log("Form loaded");
    }

    function initForm(formContext: Xrm.Mov_invoice) {
        activateTaxes(formContext);
    }

    function registerEvents(formContext: Xrm.Mov_invoice) {
        formContext.getAttribute<Xrm.Attributes.OptionSetAttribute>("mov_destination")
            .addOnChange(ev => activateTaxes(ev.getFormContext()));
    }

    function activateTaxes(formContext: Xrm.Mov_invoice) {
        // formContext.ui.setFormNotification(message, "INFO", myUniqueId);
        // window.setTimeout(function() { formContext.ui.clearFormNotification(myUniqueId); }, 5000);

        const destinationAtribute = formContext.getAttribute("mov_destination");
        const taxesControl = formContext.getControl("mov_taxes");

        const taxesAtribute = taxesControl.getAttribute();

        if (destinationAtribute != null) {
            const destinationValue = destinationAtribute.getValue();
            if (destinationValue == 865320001) {
                taxesAtribute.setRequiredLevel("required");
                taxesControl.setVisible(true);
            } else {
                taxesAtribute.setRequiredLevel("none");
                taxesControl.setVisible(false);

            }
        }

    }


}