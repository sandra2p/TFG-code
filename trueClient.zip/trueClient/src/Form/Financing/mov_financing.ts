export namespace Financing {
    export function onLoad(executionContext: Xrm.Events.EventContext) {
        const formContext: Xrm.Mov_financing = executionContext.getFormContext();
        registerEvents(formContext);
        initForm(formContext);
        console.log("Form loaded");
    }

    function initForm(formContext: Xrm.Mov_financing) {
        calculateShare(formContext);
    }

    function registerEvents(formContext: Xrm.Mov_financing) {
        formContext.getAttribute<Xrm.Attributes.NumberAttribute>("mov_fraction")
            .addOnChange(ev => calculateShare(ev.getFormContext()));
            formContext.getAttribute<Xrm.Attributes.NumberAttribute>("mov_interest")
            .addOnChange(ev => calculateShare(ev.getFormContext()));
    }

    async function calculateShare(formContext: Xrm.Mov_financing) {
        const interest= formContext.getAttribute("mov_interest").getValue();
        const fractions= formContext.getAttribute("mov_fraction").getValue();

        const invoiceAtt=formContext.getAttribute<Xrm.Attributes.LookupAttribute>("mov_invoice");
        const invoiceRef= (invoiceAtt.getValue()??[]).find(()=> true);
        if(!invoiceRef)return;
        const invoiceEntity= await Xrm.WebApi.retrieveRecord(
            invoiceRef.entityType,
            invoiceRef.id,
            "?$select=mov_totalinvoice, mov_taxes, mov_destination",
        );
     
        var total= invoiceEntity.mov_totalinvoice;  
        const taxes= invoiceEntity.mov_taxes;
        total= (1+(taxes*0.01))*total;
        
        var shares= (total*(1+(interest!*0.01)))/fractions!;

        formContext.getAttribute("mov_share").setValue(shares);

    }
}
