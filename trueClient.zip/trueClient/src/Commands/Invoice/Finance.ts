export class Finance {
    static getFinance(formContext: Xrm.Mov_invoice) {

         var name= formContext.getAttribute("mov_id").getValue();
         var id= formContext.data.entity.getId();

        const entityFormOptions={
            entityName: "mov_financing"
        };

        var formParameters={
            mov_invoice:id,
            mov_invoicename:name!,
            mov_interest: "10.1"
        };

        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(
            function (success) {
                console.log(success, formParameters);
            },
            function (error) {
                console.log(error, formParameters);
            });

    }
}