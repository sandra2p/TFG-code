export class Payment{
    static setPayment(formContext: Xrm.Mov_invoice) {

        const paymentAtribute = formContext.getAttribute("mov_paid");
        const paymentValue = paymentAtribute.getValue();

        if (paymentValue == false) {
            paymentAtribute.setValue(true);
        } else {
            paymentAtribute.setValue(false);

        }
    }
}