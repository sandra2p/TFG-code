const path = require("path");
const { CleanWebpackPlugin } = require("clean-webpack-plugin");
module.exports = {
    devtool: "source-map",
    entry: {
        index: "./src/index"
    },
    output: {
        // filename: "[name].js",
        // sourceMapFilename: "maps/[name].js.map",
        filename: "MOVInvoiceManagement.js",
        sourceMapFilename: "maps/MOVInvoiceManagement.js.map",
        path: path.resolve(__dirname, "./Webresources/scripts"),
        library: ["InvoiceManagement"],
        libraryTarget: "var",
    },
    module: {
        rules: [{
            test: /\.(ts|tsx)$/,
            use: "ts-loader",
            exclude: /node_modules/,
        }, ],
    },
    plugins: [new CleanWebpackPlugin()],
    resolve: {
        extensions: [".ts", ".js"],
    },
};