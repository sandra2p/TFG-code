var InvoiceManagement;
/******/ (() => { // webpackBootstrap
/******/ 	"use strict";
/******/ 	var __webpack_modules__ = ({

/***/ "./src/Commands/Invoice/Finance.ts":
/*!*****************************************!*\
  !*** ./src/Commands/Invoice/Finance.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Finance = void 0;
class Finance {
    static getFinance(formContext) {
        var name = formContext.getAttribute("mov_id").getValue();
        var id = formContext.data.entity.getId();
        const entityFormOptions = {
            entityName: "mov_financing"
        };
        var formParameters = {
            mov_invoice: id,
            mov_invoicename: name,
            mov_interest: "10.1"
        };
        Xrm.Navigation.openForm(entityFormOptions, formParameters).then(function (success) {
            console.log(success, formParameters);
        }, function (error) {
            console.log(error, formParameters);
        });
    }
}
exports.Finance = Finance;


/***/ }),

/***/ "./src/Commands/Invoice/Payment.ts":
/*!*****************************************!*\
  !*** ./src/Commands/Invoice/Payment.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Payment = void 0;
class Payment {
    static setPayment(formContext) {
        const paymentAtribute = formContext.getAttribute("mov_paid");
        const paymentValue = paymentAtribute.getValue();
        if (paymentValue == false) {
            paymentAtribute.setValue(true);
        }
        else {
            paymentAtribute.setValue(false);
        }
    }
}
exports.Payment = Payment;


/***/ }),

/***/ "./src/Commands/Invoice/index.ts":
/*!***************************************!*\
  !*** ./src/Commands/Invoice/index.ts ***!
  \***************************************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./Finance */ "./src/Commands/Invoice/Finance.ts"), exports);
__exportStar(__webpack_require__(/*! ./Payment */ "./src/Commands/Invoice/Payment.ts"), exports);


/***/ }),

/***/ "./src/Form/Financing/mov_financing.ts":
/*!*********************************************!*\
  !*** ./src/Form/Financing/mov_financing.ts ***!
  \*********************************************/
/***/ (function(__unused_webpack_module, exports) {


var __awaiter = (this && this.__awaiter) || function (thisArg, _arguments, P, generator) {
    function adopt(value) { return value instanceof P ? value : new P(function (resolve) { resolve(value); }); }
    return new (P || (P = Promise))(function (resolve, reject) {
        function fulfilled(value) { try { step(generator.next(value)); } catch (e) { reject(e); } }
        function rejected(value) { try { step(generator["throw"](value)); } catch (e) { reject(e); } }
        function step(result) { result.done ? resolve(result.value) : adopt(result.value).then(fulfilled, rejected); }
        step((generator = generator.apply(thisArg, _arguments || [])).next());
    });
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Financing = void 0;
var Financing;
(function (Financing) {
    function onLoad(executionContext) {
        const formContext = executionContext.getFormContext();
        registerEvents(formContext);
        initForm(formContext);
        console.log("Form loaded");
    }
    Financing.onLoad = onLoad;
    function initForm(formContext) {
        calculateShare(formContext);
    }
    function registerEvents(formContext) {
        formContext.getAttribute("mov_fraction")
            .addOnChange(ev => calculateShare(ev.getFormContext()));
        formContext.getAttribute("mov_interest")
            .addOnChange(ev => calculateShare(ev.getFormContext()));
    }
    function calculateShare(formContext) {
        var _a;
        return __awaiter(this, void 0, void 0, function* () {
            const interest = formContext.getAttribute("mov_interest").getValue();
            const fractions = formContext.getAttribute("mov_fraction").getValue();
            const invoiceAtt = formContext.getAttribute("mov_invoice");
            const invoiceRef = ((_a = invoiceAtt.getValue()) !== null && _a !== void 0 ? _a : []).find(() => true);
            if (!invoiceRef)
                return;
            const invoiceEntity = yield Xrm.WebApi.retrieveRecord(invoiceRef.entityType, invoiceRef.id, "?$select=mov_totalinvoice, mov_taxes, mov_destination");
            var total = invoiceEntity.mov_totalinvoice;
            const taxes = invoiceEntity.mov_taxes;
            total = (1 + (taxes * 0.01)) * total;
            var shares = (total * (1 + (interest * 0.01))) / fractions;
            formContext.getAttribute("mov_share").setValue(shares);
        });
    }
})(Financing = exports.Financing || (exports.Financing = {}));


/***/ }),

/***/ "./src/Form/Invoice/mov_invoice.ts":
/*!*****************************************!*\
  !*** ./src/Form/Invoice/mov_invoice.ts ***!
  \*****************************************/
/***/ ((__unused_webpack_module, exports) => {


Object.defineProperty(exports, "__esModule", ({ value: true }));
exports.Invoice = void 0;
var Invoice;
(function (Invoice) {
    function onLoad(executionContext) {
        const formContext = executionContext.getFormContext();
        registerEvents(formContext);
        initForm(formContext);
        console.log("Form loaded");
    }
    Invoice.onLoad = onLoad;
    function initForm(formContext) {
        activateTaxes(formContext);
    }
    function registerEvents(formContext) {
        formContext.getAttribute("mov_destination")
            .addOnChange(ev => activateTaxes(ev.getFormContext()));
    }
    function activateTaxes(formContext) {
        // formContext.ui.setFormNotification(message, "INFO", myUniqueId);
        // window.setTimeout(function() { formContext.ui.clearFormNotification(myUniqueId); }, 5000);
        const destinationAtribute = formContext.getAttribute("mov_destination");
        const taxesControl = formContext.getControl("mov_taxes");
        const taxesAtribute = taxesControl.getAttribute();
        if (destinationAtribute != null) {
            const destinationValue = destinationAtribute.getValue();
            if (destinationValue == 865320001) {
                taxesAtribute.setRequiredLevel("required");
                taxesControl.setVisible(true);
            }
            else {
                taxesAtribute.setRequiredLevel("none");
                taxesControl.setVisible(false);
            }
        }
    }
})(Invoice = exports.Invoice || (exports.Invoice = {}));


/***/ }),

/***/ "./src/index.ts":
/*!**********************!*\
  !*** ./src/index.ts ***!
  \**********************/
/***/ (function(__unused_webpack_module, exports, __webpack_require__) {


var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __exportStar = (this && this.__exportStar) || function(m, exports) {
    for (var p in m) if (p !== "default" && !Object.prototype.hasOwnProperty.call(exports, p)) __createBinding(exports, m, p);
};
Object.defineProperty(exports, "__esModule", ({ value: true }));
__exportStar(__webpack_require__(/*! ./Commands/Invoice */ "./src/Commands/Invoice/index.ts"), exports);
__exportStar(__webpack_require__(/*! ./Form/Invoice/mov_invoice */ "./src/Form/Invoice/mov_invoice.ts"), exports);
__exportStar(__webpack_require__(/*! ./Form/Financing/mov_financing */ "./src/Form/Financing/mov_financing.ts"), exports);


/***/ })

/******/ 	});
/************************************************************************/
/******/ 	// The module cache
/******/ 	var __webpack_module_cache__ = {};
/******/ 	
/******/ 	// The require function
/******/ 	function __webpack_require__(moduleId) {
/******/ 		// Check if module is in cache
/******/ 		var cachedModule = __webpack_module_cache__[moduleId];
/******/ 		if (cachedModule !== undefined) {
/******/ 			return cachedModule.exports;
/******/ 		}
/******/ 		// Create a new module (and put it into the cache)
/******/ 		var module = __webpack_module_cache__[moduleId] = {
/******/ 			// no module.id needed
/******/ 			// no module.loaded needed
/******/ 			exports: {}
/******/ 		};
/******/ 	
/******/ 		// Execute the module function
/******/ 		__webpack_modules__[moduleId].call(module.exports, module, module.exports, __webpack_require__);
/******/ 	
/******/ 		// Return the exports of the module
/******/ 		return module.exports;
/******/ 	}
/******/ 	
/************************************************************************/
/******/ 	
/******/ 	// startup
/******/ 	// Load entry module and return exports
/******/ 	// This entry module is referenced by other modules so it can't be inlined
/******/ 	var __webpack_exports__ = __webpack_require__("./src/index.ts");
/******/ 	InvoiceManagement = __webpack_exports__;
/******/ 	
/******/ })()
;
//# sourceMappingURL=maps/MOVInvoiceManagement.js.map